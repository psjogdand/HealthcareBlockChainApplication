-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: healthcaredb
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblhospital`
--

DROP TABLE IF EXISTS `tblhospital`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblhospital` (
  `Name` varchar(45) NOT NULL,
  `Email_IDs` varchar(45) NOT NULL,
  `Mobile_No` double NOT NULL,
  `Passwords` varchar(10) NOT NULL,
  `Address` varchar(45) NOT NULL,
  `Gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblhospital`
--

LOCK TABLES `tblhospital` WRITE;
/*!40000 ALTER TABLE `tblhospital` DISABLE KEYS */;
INSERT INTO `tblhospital` VALUES ('pax','pax@gmail.com',9503793457,'12345','Pune','Male'),('Prakash','Prakash@gmail.com',9503793456,'12345','Pune','Male');
/*!40000 ALTER TABLE `tblhospital` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblinsurance`
--

DROP TABLE IF EXISTS `tblinsurance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblinsurance` (
  `Name` varchar(45) NOT NULL,
  `Email_IDs` varchar(45) NOT NULL,
  `Mobile_No` double NOT NULL,
  `Passwords` varchar(10) NOT NULL,
  `Address` varchar(45) NOT NULL,
  `Gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblinsurance`
--

LOCK TABLES `tblinsurance` WRITE;
/*!40000 ALTER TABLE `tblinsurance` DISABLE KEYS */;
INSERT INTO `tblinsurance` VALUES ('Jay','Jay@gmail.com',9503894553,'12345','Pune','Male');
/*!40000 ALTER TABLE `tblinsurance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmasterpatient`
--

DROP TABLE IF EXISTS `tblmasterpatient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmasterpatient` (
  `First_Name` varchar(20) NOT NULL,
  `Middle_Name` varchar(20) NOT NULL,
  `Last_Name` varchar(20) NOT NULL,
  `Birth_Of_Date` varchar(10) NOT NULL,
  `Email_ID` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmasterpatient`
--

LOCK TABLES `tblmasterpatient` WRITE;
/*!40000 ALTER TABLE `tblmasterpatient` DISABLE KEYS */;
INSERT INTO `tblmasterpatient` VALUES ('Harsh','abc','Xyz','23-11-93','Harsh@gmail.com');
/*!40000 ALTER TABLE `tblmasterpatient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblregister`
--

DROP TABLE IF EXISTS `tblregister`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblregister` (
  `Name` varchar(45) NOT NULL,
  `Email_IDs` varchar(45) NOT NULL,
  `Mobile_No` double DEFAULT NULL,
  `Passwords` varchar(10) NOT NULL,
  `Address` varchar(45) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  PRIMARY KEY (`Email_IDs`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblregister`
--

LOCK TABLES `tblregister` WRITE;
/*!40000 ALTER TABLE `tblregister` DISABLE KEYS */;
INSERT INTO `tblregister` VALUES ('Prakash','prakash@gmail.com',12345,'12345','Pune','Male');
/*!40000 ALTER TABLE `tblregister` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-03 21:55:54
