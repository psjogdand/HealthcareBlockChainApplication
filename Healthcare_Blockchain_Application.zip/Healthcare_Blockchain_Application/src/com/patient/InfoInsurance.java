package com.patient;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.JavaX;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connection.Dbconn;

/**
 * Servlet implementation class InfoInsurance
 */
@WebServlet("/InfoInsurance")
public class InfoInsurance extends HttpServlet {
	private static final long serialVersionUID = 1L;
       public static String Insurance_Company;
       public static String Police_Name;
       public static String Months;
       public static String Coverage_Msg;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InfoInsurance() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw = response.getWriter();
		HttpSession session = request.getSession(false);
		String[] id = request.getParameterValues("Checkbox");
		String PatientName=(String)session.getAttribute("pname");
		String PatientEmail=(String)session.getAttribute("pemailid");
		try {
			Connection con = Dbconn.conn();
			for (String s : id) {
				
				
				Statement st = con.createStatement();
				String query1 = "select * from tblinsurance_details where I_ID='"+ s + "'";
				ResultSet rs1 = st.executeQuery(query1);
				while (rs1.next()) {
					 Insurance_Company=rs1.getString("Insurance_Company");
					 Police_Name=rs1.getString("Police_Name");
					 Months=rs1.getString("Months");
					Coverage_Msg=rs1.getString("Coverage_Msg");
				}
				PreparedStatement p1;
				String sql="insert into tblinfoinsurance(PatientName,PatientEmail,Insurance_Company,Policy_Name,Months,Coverage_Msg) values(?,?,?,?,?,?)";    JavaX.Transaction();
				p1=(PreparedStatement) con.prepareStatement(sql);
				p1.setString(1,PatientName);
				p1.setString(2,PatientEmail);
				p1.setString(3,Insurance_Company);
				p1.setString(4,Police_Name);
				p1.setString(5,Months);
				p1.setString(6,Coverage_Msg);
				p1.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		pw.println("<html><script>alert('Insurance Save Successfully');</script><body>");
		pw.println("");
		pw.println("</body></html>");
		RequestDispatcher rd = request.getRequestDispatcher("/ShowInsurancePatient.jsp");
		rd.include(request, response);
	}

}
